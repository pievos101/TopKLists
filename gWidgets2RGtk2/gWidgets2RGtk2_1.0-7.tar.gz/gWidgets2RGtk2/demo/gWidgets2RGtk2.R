## run examples
require(gWidgets2)
options(guiToolkit="RGtk2")

## run examples
source(system.file("examples", "run_examples.R", package="gWidgets2"))
