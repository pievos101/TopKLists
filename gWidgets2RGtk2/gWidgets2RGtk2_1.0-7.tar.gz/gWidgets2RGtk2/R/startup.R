##' @include icons.R
NULL



.onAttach <- function(...) {
  load_gwidget_icons()
}

.onLoad <- function(libname, pkgname) {
  
}
