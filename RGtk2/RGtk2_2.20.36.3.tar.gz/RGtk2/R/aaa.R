.virtuals <- new.env()
.fields <- new.env()
