R_RegisterCCallable("RGtk2", "S_AtkKeySnoopFunc", ((DL_FUNC)S_AtkKeySnoopFunc)); 
