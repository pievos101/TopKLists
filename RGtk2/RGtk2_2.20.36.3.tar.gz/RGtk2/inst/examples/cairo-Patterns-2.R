matrix <- cairoMatrixInitScale(0.5, 0.5)$matrix
pattern$setMatrix(matrix)

